<?php

$_lang['commerce_omise'] = 'Commerce_Omise';
$_lang['commerce_omise.description'] = 'Commerce_Omise เชื่อมต่อการชำระเงินออนไลน์ Omise เข้ากับ Commerce บน MODX';
$_lang['commerce_omise.gateway'] = 'Omise';
$_lang['commerce_omise.payment_verified'] = 'ยืนยันการชำระเงินแล้ว';
$_lang['commerce_omise.payment_not_verified'] = 'ยังไม่ได้ยืนยันการชำระเงิน';
$_lang['commerce_omise.form.name'] = 'ชื่อ';
$_lang['commerce_omise.form.number'] = 'จำนวน';
$_lang['commerce_omise.form.date'] = 'วันที่';
$_lang['commerce_omise.form.security_code'] = 'รหัสรักษาความปลอดภัย';
$_lang['commerce_omise.form.security_code_error'] = 'การตรวจสอบรหัสความปลอดภัยล้มเหลว โปรดตรวจสอบว่าคุณป้อนข้อมูลรับรองของคุณถูกต้อง';